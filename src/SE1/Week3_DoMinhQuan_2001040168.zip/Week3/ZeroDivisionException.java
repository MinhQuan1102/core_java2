package SE1.Week3;

public class ZeroDivisionException extends ArithmeticException{
    public ZeroDivisionException() {
        super();
    }

    public ZeroDivisionException(String message) {
        super(message);
    }
}
