package SE1.Week1;

public class Main {
    public static void main(String[] args) throws Exception {
        Car car1 = new Car("Tesla", 6.4, 5.2, 2.6, 1300.0, 4, "ABCDD");
        System.out.println(car1.toString());
    }
}
